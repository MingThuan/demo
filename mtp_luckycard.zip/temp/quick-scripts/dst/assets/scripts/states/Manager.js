
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/states/Manager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '149c49h1I5G55Ds5PjkIgDf', 'Manager');
// scripts/states/Manager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var InGame_1 = require("./InGame");
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.preLoad = null;
        _this.inGame = null;
        return _this;
    }
    Manager_1 = Manager;
    // LIFE-CYCLE CALLBACKS:
    Manager.prototype.onLoad = function () {
        Manager_1.Instance = this;
        this.timerFade = 0.5;
        this.stateNext = null;
        this.preLoad.active = true;
        this.inGame.active = false;
        console.log('onLoad Manager');
    };
    Manager.prototype.start = function () {
    };
    Manager.prototype.SwitchState = function (state, isFade) {
        if (isFade === void 0) { isFade = true; }
        console.log('SwitchState Manager');
        console.log(state instanceof InGame_1.default);
    };
    Manager.prototype.update = function (dt) {
    };
    var Manager_1;
    __decorate([
        property(cc.Node)
    ], Manager.prototype, "preLoad", void 0);
    __decorate([
        property(cc.Node)
    ], Manager.prototype, "inGame", void 0);
    Manager = Manager_1 = __decorate([
        ccclass
    ], Manager);
    return Manager;
}(cc.Component));
exports.default = Manager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc3RhdGVzXFxNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDLG1DQUFrQztBQUdsQztJQUFxQywyQkFBWTtJQUFqRDtRQUFBLHFFQXNDQztRQWxDRyxhQUFPLEdBQVksSUFBSSxDQUFDO1FBRXhCLFlBQU0sR0FBWSxJQUFJLENBQUM7O0lBZ0MzQixDQUFDO2dCQXRDb0IsT0FBTztJQVd4Qix3QkFBd0I7SUFFeEIsd0JBQU0sR0FBTjtRQUNJLFNBQU8sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBRXhCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBRXRCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFFM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO0lBQ2pDLENBQUM7SUFFRCx1QkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVNLDZCQUFXLEdBQWxCLFVBQW1CLEtBQVUsRUFBRSxNQUFzQjtRQUF0Qix1QkFBQSxFQUFBLGFBQXNCO1FBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssWUFBWSxnQkFBVyxDQUFDLENBQUE7SUFFN0MsQ0FBQztJQUVELHdCQUFNLEdBQU4sVUFBTyxFQUFFO0lBRVQsQ0FBQzs7SUFqQ0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzs0Q0FDTTtJQUV4QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzJDQUNLO0lBTk4sT0FBTztRQUQzQixPQUFPO09BQ2EsT0FBTyxDQXNDM0I7SUFBRCxjQUFDO0NBdENELEFBc0NDLENBdENvQyxFQUFFLENBQUMsU0FBUyxHQXNDaEQ7a0JBdENvQixPQUFPIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbmltcG9ydCB7R2FtZURlZmluZX0gZnJvbSAnLi4vZ2FtZS9HYW1lRGVmaW5lJ1xyXG5pbXBvcnQgU3RhdGVJbkdhbWUgZnJvbSAnLi9JbkdhbWUnXHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNYW5hZ2VyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuICAgIHB1YmxpYyBzdGF0aWMgSW5zdGFuY2U6IE1hbmFnZXI7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcmVMb2FkOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgaW5HYW1lOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICB0aW1lckZhZGU6IG51bWJlcjtcclxuICAgIHN0YXRlTmV4dDogY2MuTm9kZTtcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgTWFuYWdlci5JbnN0YW5jZSA9IHRoaXM7XHJcblxyXG4gICAgICAgIHRoaXMudGltZXJGYWRlID0gMC41O1xyXG4gICAgICAgIHRoaXMuc3RhdGVOZXh0ID0gbnVsbDtcclxuXHJcbiAgICAgICAgdGhpcy5wcmVMb2FkLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5pbkdhbWUuYWN0aXZlID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvbkxvYWQgTWFuYWdlcicpXHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBTd2l0Y2hTdGF0ZShzdGF0ZTogYW55LCBpc0ZhZGU6IGJvb2xlYW4gPSB0cnVlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1N3aXRjaFN0YXRlIE1hbmFnZXInKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhzdGF0ZSBpbnN0YW5jZW9mIFN0YXRlSW5HYW1lKVxyXG5cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuXHJcbiAgICB9XHJcbn1cclxuIl19