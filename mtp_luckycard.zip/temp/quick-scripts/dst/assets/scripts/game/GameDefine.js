
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/game/GameDefine.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'be5dbpqYfpFIYKz6vg1hnGO', 'GameDefine');
// scripts/game/GameDefine.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameDefine = void 0;
var n = 0;
exports.GameDefine = {
    GAME_WIDTH: 576,
    GAME_HEIGHT: 1024,
    GAME_GROUND: -240,
    GAME_DEBUG: false,
    STATE_PRELOAD: n++,
    STATE_INGAME: n++,
    STATE_POPUP_GET_1_ATTEMPT: n++,
    STATE_POPUP_CHOOSE_GIFT: n++,
    STATE_POPUP_CONGRATULATIONS: n++,
    STATE_POPUP_OUT_OF_PLAY: n++,
    STATE_POPUP_MORE_INFO: n++,
    STATE_POPUP_REDEEM: n++,
    STATE_POPUP_REDEEM_ZONE: n++,
    STATE_POPUP_GAME_RULES: n++
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZ2FtZVxcR2FtZURlZmluZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDRyxRQUFBLFVBQVUsR0FBRztJQUN0QixVQUFVLEVBQUUsR0FBRztJQUNmLFdBQVcsRUFBRSxJQUFJO0lBQ2pCLFdBQVcsRUFBRSxDQUFDLEdBQUc7SUFDakIsVUFBVSxFQUFFLEtBQUs7SUFFakIsYUFBYSxFQUFtQixDQUFDLEVBQUU7SUFDbkMsWUFBWSxFQUFvQixDQUFDLEVBQUU7SUFDbkMseUJBQXlCLEVBQU8sQ0FBQyxFQUFFO0lBQ25DLHVCQUF1QixFQUFTLENBQUMsRUFBRTtJQUNuQywyQkFBMkIsRUFBSyxDQUFDLEVBQUU7SUFDbkMsdUJBQXVCLEVBQVMsQ0FBQyxFQUFFO0lBQ25DLHFCQUFxQixFQUFXLENBQUMsRUFBRTtJQUNuQyxrQkFBa0IsRUFBYyxDQUFDLEVBQUU7SUFDbkMsdUJBQXVCLEVBQVMsQ0FBQyxFQUFFO0lBQ25DLHNCQUFzQixFQUFVLENBQUMsRUFBRTtDQUN0QyxDQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsibGV0IG4gPSAwO1xyXG5leHBvcnQgY29uc3QgR2FtZURlZmluZSA9IHtcclxuICAgIEdBTUVfV0lEVEg6IDU3NixcclxuICAgIEdBTUVfSEVJR0hUOiAxMDI0LFxyXG4gICAgR0FNRV9HUk9VTkQ6IC0yNDAsXHJcbiAgICBHQU1FX0RFQlVHOiBmYWxzZSxcclxuXHJcbiAgICBTVEFURV9QUkVMT0FEOiAgICAgICAgICAgICAgICAgIG4rKyxcclxuICAgIFNUQVRFX0lOR0FNRTogICAgICAgICAgICAgICAgICAgbisrLFxyXG4gICAgU1RBVEVfUE9QVVBfR0VUXzFfQVRURU1QVDogICAgICBuKyssXHJcbiAgICBTVEFURV9QT1BVUF9DSE9PU0VfR0lGVDogICAgICAgIG4rKyxcclxuICAgIFNUQVRFX1BPUFVQX0NPTkdSQVRVTEFUSU9OUzogICAgbisrLFxyXG4gICAgU1RBVEVfUE9QVVBfT1VUX09GX1BMQVk6ICAgICAgICBuKyssXHJcbiAgICBTVEFURV9QT1BVUF9NT1JFX0lORk86ICAgICAgICAgIG4rKyxcclxuICAgIFNUQVRFX1BPUFVQX1JFREVFTTogICAgICAgICAgICAgbisrLFxyXG4gICAgU1RBVEVfUE9QVVBfUkVERUVNX1pPTkU6ICAgICAgICBuKyssXHJcbiAgICBTVEFURV9QT1BVUF9HQU1FX1JVTEVTOiAgICAgICAgIG4rK1xyXG59XHJcbiJdfQ==