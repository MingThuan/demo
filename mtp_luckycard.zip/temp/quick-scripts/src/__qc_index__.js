
require('./assets/scripts/game/Card');
require('./assets/scripts/game/CardMgr');
require('./assets/scripts/game/GameDefine');
require('./assets/scripts/states/InGame');
require('./assets/scripts/states/Manager');
require('./assets/scripts/states/PreLoad');
require('./assets/scripts/states/popup/GetOneAttempt');
