const {ccclass, property} = cc._decorator;

@ccclass
export default class InGame extends cc.Component {
    public static Instance: InGame;

    @property(cc.Label)
    label: cc.Label = null;

    @property
    text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        console.log('onLoad InGame')
        InGame.Instance = this;
    }

    start () {

    }

    // update (dt) {}
}
