const { ccclass, property } = cc._decorator;

import {GameDefine} from '../game/GameDefine'
import StateInGame from './InGame'

@ccclass
export default class Manager extends cc.Component {
    public static Instance: Manager;

    @property(cc.Node)
    preLoad: cc.Node = null;
    @property(cc.Node)
    inGame: cc.Node = null;

    timerFade: number;
    stateNext: cc.Node;

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        Manager.Instance = this;

        this.timerFade = 0.5;
        this.stateNext = null;

        this.preLoad.active = true;
        this.inGame.active = false;

        console.log('onLoad Manager')
    }

    start() {

    }

    public SwitchState(state: any, isFade: boolean = true) {
        console.log('SwitchState Manager');
        console.log(state instanceof StateInGame)

    }

    update(dt) {

    }
}
