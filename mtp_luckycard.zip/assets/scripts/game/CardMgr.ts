const { ccclass, property } = cc._decorator;
import { GameDefine } from './game/GameDefine';

@ccclass
export default class CardMgr extends cc.Component {

    @property(cc.Prefab)
    prefab: cc.Prefab = null;

    listChild: Array<cc.Node>;

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.listChild = new Array<cc.Node>();
        for (let i = 0; i < this.node.children.length; i++) {
            let card = cc.instantiate(this.prefab);
            card.active = true;
            card.parent = this.node.children[i];

            let cardScript = card.getComponent('Card');
            cardScript.Init(i);
        }
    }

    start() {

    }

    // update (dt) {}

    add() {
        let card = cc.instantiate(this.prefab);
        card.active = true;
        // card.parent
    }
}
