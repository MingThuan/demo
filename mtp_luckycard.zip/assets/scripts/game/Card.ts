const {ccclass, property} = cc._decorator;

@ccclass
export default class Card extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property([cc.SpriteFrame])
    sprites : cc.SpriteFrame[] = [];

    @property
    text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.on(cc.Node.EventType.TOUCH_END, function(event){
            alert(1)
        }, this);
    }

    start () {

    }

    public Init(id: number)
    {
        this.node.children[0].getComponent(cc.Sprite).spriteFrame = this.sprites[id];
    }

    // update (dt) {}
}
